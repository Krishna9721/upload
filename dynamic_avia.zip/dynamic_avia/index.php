<?php
echo 'Sorry, browsing the directory is not allowed!';
?>